%% MODEL VERIFICATION
clc;
clear; % Removes variables from the workspace
close all
%% Parameter estimates
J = 0.01;
b = 0.1;
K = 0.01;
R = 1;
L = 0.5;
s = tf('s');
P_motor = K/((J*s+b)*(L*s+R)+K^2)
 
%% State Space
A = [-b/J   K/J
    -K/L   -R/L];
B = [0
    1/L];
C = [1   0];
D = 0;
motor_ss = ss(A,B,C,D)
 
%% Modelling The DC motor Control with PID 
s = tf('s');
P_motor = K/((J*s+b)*(L*s+R)+K^2);
zpk(P_motor)
Kp=100;
C=pid(Kp);
sys_cl=feedback(C*P_motor,1)
 
%% closed loop step response
 
 figure (1)
 t = 0:0.01:5;
 step(sys_cl,t)
 grid
 title('Step Response with Proportional Control')
 
 
 %% PID CONTROLLER DESIGN
 Kp=50;
 Ki=0;
 Kd=0;
 C=pid(Kp,Ki,Kd);
 sys_cl=feedback(C*P_motor,1)

 figure (2)
 step(sys_cl,[0:1:200])
 grid on
 title('PID Control with Proportional Constant (kp=50)')
 legend('kp=50')
 
 %% Tuning the gains
 
Kp = 100;
Ki = 0;
Kd = 0;
C = pid(Kp,Ki,Kd);
sys_cl = feedback(C*P_motor,1);

figure (3)
step(sys_cl, 0:0.01:4)
grid
title('PID Control with Proportional Constant (kp=100)')
 legend('kp=100')
% increasing the Kd reduces the overshoot
 Kp = 100;
 Ki = 200;
 Kd = 0;
 C = pid(Kp,Ki,Kd);
 sys_cl = feedback(C*P_motor,1);

 figure (4)
 step(sys_cl, 0:0.01:4)
 grid
 title('PID Control with Large Ki and Large Kp')
 legend ('Kp=100 , Ki=200')

 
 %% adding the derivative constant
 Kp = 100;
 Ki = 200;
 Kd = 10;
 C = pid(Kp,Ki,Kd);
 sys_cl = feedback(C*P_motor,1);

 figure (5)
 step(sys_cl, 0:0.01:4)
 grid
 title('PID Control of DC motor ')
 legend ('Kp=100 , Ki=200 , kd=10')