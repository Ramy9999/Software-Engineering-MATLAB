
 
function varargout = Power_signals2(varargin)



% POWER_SIGNALS2 MATLAB code for Power_signals2.fig
%      POWER_SIGNALS2, by itself, creates a new POWER_SIGNALS2 or raises the existing
%      singleton*.
%
%      H = POWER_SIGNALS2 returns the handle to a new POWER_SIGNALS2 or the handle to
%      the existing singleton*.
%
%      POWER_SIGNALS2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in POWER_SIGNALS2.M with the given input arguments.
%
%      POWER_SIGNALS2('Property','Value',...) creates a new POWER_SIGNALS2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Power_signals2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Power_signals2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Power_signals2

% Last Modified by GUIDE v2.5 26-Nov-2017 14:01:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Power_signals2_OpeningFcn, ...
                   'gui_OutputFcn',  @Power_signals2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Power_signals2 is made visible.
function Power_signals2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Power_signals2 (see VARARGIN)

% Choose default command line output for Power_signals2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Power_signals2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Power_signals2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in load.
function load_Callback(hObject, eventdata, handles)
% Loads Uapp as File1 and saves data as t1 and Uapp variables to GUI:
[File1] = uigetfile('*.txt');
[t1, Uapp] = textread(File1);

% Loads Vc as File2 and saves data as t2 and Vc variables to GUI:
[File2] = uigetfile('*.txt');
[t2, Vc] = textread(File2);

% Saves variables t1, t2, Uapp and Vc to workspace: 
assignin('base','t1',t1);
assignin('base','Uapp',Uapp);
assignin('base','t2',t2);
assignin('base','Vc',Vc);



% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)

% Extracts the values of Uapp, t1, t2 and Vc from workspace: 
Uapp = evalin('base','Uapp');
Vc = evalin('base','Vc');
t1 = evalin('base','t1');
t2 = evalin('base','t2');

% Calculates the rms values of Vc and Uapp:
rmsVc = rms(Vc);
peaktopeakVc = peak2peak(Vc);

% Calculates the peak to peak values of Vc and Uapp:
rmsUapp = rms(Uapp);
peaktopeakUapp = peak2peak(Uapp);

 %Plots time resolved signal on two y axes:  
if get(handles.checkbox1,'Value')
Time_Resolved.handles = plot(handles.Time_Resolved,t1,Uapp/1000,'r',t2, Vc,'g');
set(handles.edit3, 'String', num2str(peaktopeakVc));
set(handles.edit5, 'String', num2str(peaktopeakUapp));
set(handles.edit4, 'String', num2str(rmsVc));
set(handles.edit6, 'String', num2str(rmsUapp));
end




% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% Extracts the values of Uapp, t1, t2 and Vc from the workspace: 
Uapp = evalin('base','Uapp');
t1 = evalin('base','t1');
t2 = evalin('base','t2');
Vc = evalin('base','Vc');

% Calculates value of the frequency of channel 1:
max_pt = (find(Uapp == max(Uapp)));
period = t1(max_pt(2)) - t1(max_pt(1));
frequency1 = 1/period;

% Saves the variable frequency1 to workspace:
assignin('base','frequency1',frequency1);

% Extracts the value of frequency1 from the workspace: 
frequency1 = evalin('base','frequency1');

% Calculates value of the frequency of channel 2:
max_pt2 = (find(Vc == max(Vc)));
period1 = t2(max_pt(2)) - t2(max_pt(1));
frequency2 = 1/period1;

% Saves the variable frequency2 to workspace:
assignin('base','frequency2',frequency2);

% Extracts the value of frequency2 from the workspace: 
frequency2 = evalin('base','frequency2');

%Displays values of the frequencies for both channels:
if get(handles.checkbox2,'Value')
set(handles.frequnecy_channel1, 'String', num2str(frequency1));
set(handles.frequency_channel2, 'String', num2str(frequency2));
end





% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% Extracts the value of Vc from the workspace: 
Vc = evalin('base','Vc');

% Calculates values of c and q:
c = 22*10^-9;
q = c.*Vc;

% Saves the variables c and q to the workspace:
assignin('base','c',c);
assignin('base','q',q);
assignin('base','Vc',Vc);

% Extracts the values of Uapp, c and q from the workspace: 
Uapp = evalin('base','Uapp');
c = evalin('base','c');
q = evalin('base','q');

%Plots the Lissajous figure:
if get(handles.checkbox3,'Value')
handles.axes5 = plot(Uapp, q);
end


% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% Extracts the value of Uapp, t1, t2, q and Vc from the workspace: 
Uapp = evalin('base','Uapp');
t1 = evalin('base','t1');
t2 = evalin('base','t2');
q = evalin('base','q');
Vc = evalin('base','Vc');

%Calculates the period:
max_pt = (find(Uapp == max(Uapp)));
period = t1(max_pt(2)) - t1(max_pt(1));
freq = 1/period;

%Calculates the value of W:
n = 1; W = 0;
while t1(n)<= period
    
    Acc = (0.5.*(Uapp(n+1)+ Uapp(n))).*(q(n+1)- q(n));
    W = Acc + W;
    n = n + 1;
    
end

P = W*freq;

% Saves the variables P, W and Acc to the workspace:
assignin('base','P',P);
assignin('base','W',W);
assignin('base','Acc',Acc);

%Plots the Power Data:
if get(handles.checkbox4,'Value')
    axes3.handles = plot(handles.axes3,t1,Uapp/1000,'c',t2, Vc,'m');
end


% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% Clears data displayed in Text boxes:
set(handles.edit3, 'String', []);
set(handles.edit5, 'String', []);
set(handles.edit4, 'String', []);
set(handles.edit6, 'String', []);
set(handles.frequnecy_channel1, 'String', []);
set(handles.frequency_channel2, 'String', []);

% Clears data from graphs:
cla (handles.Time_Resolved, 'reset');
cla (handles.axes5, 'reset');
cla (handles.axes3, 'reset');



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 p = peak2peak(t1,Vu);
 

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
r = rms(t1,Vu);


% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p = peak2peak(t2,Vc);

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
r = rms(t2,Vc);

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frequnecy_channel1_Callback(hObject, eventdata, handles)
% hObject    handle to frequnecy_channel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frequnecy_channel1 as text
%        str2double(get(hObject,'String')) returns contents of frequnecy_channel1 as a double
if (checkbox2)
Uapp = evalin('base','Uapp');
max_pt = evalin('base','max_pt');
period = evalin('base','period');
freq = evalin('base','freq');
max_pt = (find(Uapp == max(Uapp)));
period = t1(max_pt(2)) - t1(max_pt(1));
freq = 1/period;
% freq = sprintf('M(3) = %.3f', M(3));
freqstring = num2str(freq);
set(handles.frequnecy_channel1, 'String', freqstring);
end


% --- Executes during object creation, after setting all properties.
function frequnecy_channel1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frequnecy_channel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frequency_channel2_Callback(hObject, eventdata, handles)
% hObject    handle to frequency_channel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frequency_channel2 as text
%        str2double(get(hObject,'String')) returns contents of frequency_channel2 as a double


% --- Executes during object creation, after setting all properties.
function frequency_channel2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frequency_channel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function uapp_input_Callback(hObject, eventdata, handles)
% hObject    handle to uapp_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of uapp_input as text
%        str2double(get(hObject,'String')) returns contents of uapp_input as a double
[t1, Vu] = textread('Uapp.txt');



% --- Executes during object creation, after setting all properties.
function uapp_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uapp_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
[t1,Uapp] = textread('Uapp.txt');


function uc_input_Callback(hObject, eventdata, handles)
% hObject    handle to uc_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of uc_input as text
%        str2double(get(hObject,'String')) returns contents of uc_input as a double

[t2, Vc] = textread('Uc.txt');

% --- Executes during object creation, after setting all properties.
function uc_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uc_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in smooth.
function smooth_Callback(hObject, eventdata, handles)
% hObject    handle to smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smooth

Uapp = evalin('base','Uapp');
q = evalin('base','q');

max_pt = (find(Uapp == max(Uapp)));
sample = (max_pt(4)) - (max_pt(1));
qsmooth = smooth(q(1:sample), 0.1);
Uappsmooth = smooth (Uapp(1:sample), 0.1);

assignin('base','Uappsmooth',Uappsmooth);
assignin('base','qsmooth',qsmooth);


Uappsmooth = evalin('base','Uappsmooth');
qsmooth = evalin('base','qsmooth');


if get(handles.smooth,'Value')
handles.axes5 = plot(Uappsmooth, qsmooth);
end
